<?php
session_start();
include_once("fonctions-panier.php");

$erreur = false;

$action = (isset($_POST['action'])? $_POST['action']:  (isset($_GET['action'])? $_GET['action']:null )) ;
if($action !== null)
{
   if(!in_array($action,array('ajout', 'suppression', 'refresh')))
   $erreur=true;

   //récupération des variables en POST ou GET
   $l = (isset($_POST['l'])? $_POST['l']:  (isset($_GET['l'])? $_GET['l']:null )) ;
   $p = (isset($_POST['p'])? $_POST['p']:  (isset($_GET['p'])? $_GET['p']:null )) ;
   $q = (isset($_POST['q'])? $_POST['q']:  (isset($_GET['q'])? $_GET['q']:null )) ;

   //Suppression des espaces verticaux
   $l = preg_replace('#\v#', '',$l);
   //On vérifie que $p est un float
   $p = floatval($p);

   //On traite $q qui peut être un entier simple ou un tableau d'entiers
    
   if (is_array($q)){
      $QteArticle = array();
      $i=0;
      foreach ($q as $contenu){
         $QteArticle[$i++] = intval($contenu);
      }
   }
   else
   $q = intval($q);
    
}

if (!$erreur){
   switch($action){
      Case "ajout":
         ajouterArticle($l,$q,$p);
         break;

      Case "suppression":
         supprimerArticle($l);
         break;

      Case "refresh" :
         for ($i = 0 ; $i < count($QteArticle) ; $i++)
         {

            modifierQTeArticle($_SESSION['panier']['libelleProduit'][$i],round($QteArticle[$i]));
         }
         break;

      Default:
         break;
   }
}

echo '<?xml version="1.0" encoding="utf-8"?>';?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
<title>Votre panier</title>
<link rel="stylesheet" type="text/css" href="Accueil1.css">
</head>
<body>
<div id="banner1">
          <p> planete des jeux video PS4 </p>
        </div><br><br><br>
        <div id="menu">
           <ul>
           <li class="Acceuil"><a href="projet.php"><i class="fas fa-home"></i>     Acceuil</a></li>
              <li class="pn"><a href="panier.php"><i class="fas fa-shopping-cart"></i>  Panier</a></li>
              


    <li class="cnx"><a href="seconnecter.php">Connexion</a>
     <ul> 
      <?php if(!isset($_SESSION['ID'])){ ?>         
        <li class="secn"><a href="seconnecter.php"><i class="fas fa-sign-in-alt"></i> Se connecter</a></li>
        <li class="ins"><a href="inscription.php"><i class="far fa-edit"></i>S'inscrir
        </li> 
        <?php } else {?> 
        <li class="ins"><a href="sedecn.php"><i class="far fa-edit"></i>se deconnecter
        </li>
        <?php }?>
      </ul> 
    </li>



              <li class="jeux"><a href="jeux.php"><i class="fas fa-gamepad"></i>
    Les Jeux</a>
                  <ul>
                   <li class="avn"><a href="avanture.php"> <b>Avanture</b></a></li>
                   <li class="crs"><a href="course.php"> <b>course</b></a></li>
                   <li class="spr"><a href="sport.php"> <b>Sport</b></a></li>
                   <li class="br"><a href="br.php"> <b>Battle Royale</b></a></li>
                </ul>
              </li>
              <li class="sc"><a href="Contact.php"><i class="fas fa-info-circle"></i>       Service client</a>
                <ul>
                   <li class="cnt"><a href="Contacter.php"> <b><i class="fas fa-phone-square"></i>
                    Contactez-nous</b></a></li>
                   <li class="sld"><a href="Solde.php"> <b>Solde</b></a></li>
                </ul>
              </li>
              
           </ul>
        </div><br><br><br><br><br><br><br>
<div id="container">
<form method="post" action="">
  <h1>Panier</h1>
<table style="width: 400px">
    
    <tr>
        <td>nom du jeux</td>
        <td>Quantité</td>
        <td>Prix en DH</td>
        <td>Action</td>
    </tr>

</div>

    <?php
    if (creationPanier())
    {
       $nbArticles=count($_SESSION['panier']['libelleProduit']);
       if ($nbArticles <= 0)
       echo "<tr><td>Votre panier est vide </ td></tr>";
       else
       {
          for ($i=0 ;$i < $nbArticles ; $i++)
          {
             echo "<tr>";
             echo "<td>".htmlspecialchars($_SESSION['panier']['libelleProduit'][$i])."</ td>";
             echo "<td><input type=\"text\" size=\"4\" name=\"q[]\" value=\"".htmlspecialchars($_SESSION['panier']['qteProduit'][$i])."\"/></td>";
             echo "<td>".htmlspecialchars($_SESSION['panier']['prixProduit'][$i])."</td>";
             echo "<td><a href=\"".htmlspecialchars("panier.php?action=suppression&l=".rawurlencode($_SESSION['panier']['libelleProduit'][$i]))."\">retirer</a></td>";
             echo "</tr>";
          }

          echo "<tr><td colspan=\"2\"> </td>";
          echo "<td colspan=\"2\">";
          echo "Total : ".MontantGlobal();
          echo "</td></tr>";

          echo "<tr><td colspan=\"4\">";
          echo "<input type=\"submit\" value=\"Rafraichir\"/>";
          echo "<input type=\"hidden\" name=\"action\" value=\"refresh\"/>";

          echo "</td></tr>";
       }
    }
    ?>

</table></form>
<form method="POST" action="abb.php">
<input type="submit" value="ajouter un autre jeux au panier" name="ajt">
<input type="submit" value="Valider la commande" name="Valider">
</form>



</body>
</html>
