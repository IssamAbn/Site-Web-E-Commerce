<?php 
require("CnxBd.php");
$lien=connectMaBasi();
session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="Accueil1.css">
</head>
<body>
<div id="menu">
           <ul>
           <li class="Acceuil"><a href="projet.php"><i class="fas fa-home"></i>     Acceuil</a></li>
              <li class="pn"><a href="panier.php"><i class="fas fa-shopping-cart"></i>  Panier</a></li>
              


    <li class="cnx"><a href="seconnecter.php">Connexion</a>
     <ul> 
      <?php if(!isset($_SESSION['ID'])){ ?>         
        <li class="secn"><a href="seconnecter.php"><i class="fas fa-sign-in-alt"></i> Se connecter</a></li>
        <li class="ins"><a href="inscription.php"><i class="far fa-edit"></i>S'inscrir
        </li> 
        <?php } else {?> 
        <li class="ins"><a href="sedecn.php"><i class="far fa-edit"></i>se deconnecter
        </li>
        <?php }?>
      </ul> 
    </li>



              <li class="jeux"><a href="jeux.php"><i class="fas fa-gamepad"></i>
    Les Jeux</a>
                  <ul>
                   <li class="avn"><a href="avanture.php"> <b>Avanture</b></a></li>
                   <li class="crs"><a href="course.php"> <b>course</b></a></li>
                   <li class="spr"><a href="sport.php"> <b>Sport</b></a></li>
                   <li class="br"><a href="br.php"> <b>Battle Royale</b></a></li>
                </ul>
              </li>
              <li class="sc"><a href="Contact.php"><i class="fas fa-info-circle"></i>       Service client</a>
                <ul>
                   <li class="cnt"><a href="Contacter.php"> <b><i class="fas fa-phone-square"></i>
                    Contactez-nous</b></a></li>
                   <li class="sld"><a href="Solde.php"> <b>Solde</b></a></li>
                </ul>
              </li>
              
           </ul>
        </div><br><br><br><br><br><br><br>




<div id="container">
            <!-- zone de connexion -->
            
            <form  method="POST">
                <h1>Finalisation de la commande</h1>
                
                <h3><u> 1.ADRESSE:</u></h3>
                <?php $id=$_SESSION['ID']; 
                $query="SELECT * FROM client WHERE ID=$id"; 
                      $reslt=mysqli_query($lien,$query);
                      $tab=mysqli_fetch_array($reslt); 
                       echo "&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp".$tab[1]."<br>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  ".$tab[4];
                 ?><br>
                <h3><u>2.MODE DE LIVRAISON</u></h3>
                   <input type="radio" name="civi" value="Mme" /> Livraison standard<br>
                   <input type="radio" name="civi" value="Mlle" /> Livraison en point relais<br>
                   <input type="radio" name="civi" value="Mr" /> Envoi Postal Economique<br>
                <h3><u>2.MODE DE PAIEMENT</u></h3>
                   <input type="checkbox" name="civi1" value="Mme" /> Paiement par carte bancaire<br>
                   <input type="checkbox" name="civi" value="Mlle" /> Paiement cash à la livraison<br>
                <input type="submit" id='submit' name="continuer" value='Continuer' >

                
            </form>
        </div>
<?php if (isset($_POST['continuer'])) {
	if (isset($_POST['civi1'])) {
		header('location:paiement.php');
	}
	else{

          $id=$_SESSION['ID'];
          $date = date("Y-m-d");
          $qu = " SELECT Num FROM commande ORDER BY Num DESC LIMIT  1 ";
                  $res = mysqli_query($lien,$qu);
                  while($pan=mysqli_fetch_assoc($res))
                  {
                  $num=$pan['Num'] + 1 ;
                  } 
          $x = "INSERT INTO commande (Num,Date,Numclt) VALUES ('$num','$date','$id')";
                  $res1 = mysqli_query($lien,$x);
          for($i = 0; $i < count($_SESSION['panier']['libelleProduit']); $i++)
          {
            $des = $_SESSION['panier']['libelleProduit'][$i];
            $qt  = $_SESSION['panier']['qteProduit'][$i];
            $query1 = "SELECT Reference FROM produit WHERE Designation='$des'";
                        
                        $resultat=mysqli_query($lien,$query1);
              

                while($tab=mysqli_fetch_assoc($resultat)){

                        $ref = $tab['Reference'];}
                             
            $query2 =" INSERT INTO lignedecommande (Refprod,Numcmd,Quantite) VALUES ('$ref','$num','$qt')";

                        mysqli_query($lien,$query2);

             
          } 
  unset($_SESSION['panier']);            
 header('location:projet.php');
}
 
  }       ?>       
</body>
</html>