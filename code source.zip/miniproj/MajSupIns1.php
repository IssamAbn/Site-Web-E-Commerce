 <?php  
    require("CnxBd.php");
    $lien=connectMaBasi();
    $ID     =$_POST['ID'];
    $Nom    =$_POST['Nom'];
    $Tel    =$_POST['Tel'];
    $Ville  =$_POST['Ville'];
    $Adress =$_POST['Adress'];
    $password=$_POST['mdp'];
    if (isset($_POST['insérer1']))
       {
           $sql = "INSERT INTO client (ID,Nom,Tel,Ville,adresse,Motdepasse) VALUES ('$ID','$Nom','$Tel','$Ville','$Adress','$password')";
                mysqli_query ($lien,$sql);
                echo '<p align="center">un client avec l\'ID <u>'.$ID.'</u> est bien inserer dans la table client</p>';
        }
 //==================================================================================================  
    if (isset($_POST['Maj1']))
       {     
                $sql = "UPDATE client SET Nom='$Nom' , Tel='$Tel' , Ville='$Ville' , Adresse='$Adress' WHERE ID=$ID";
                mysqli_query ($lien,$sql);
                echo '<p align="center">un client avec l\'ID <u>'.$ID.'</u> est mise a jour dans la table client.</p>';
        }
 //====================================================================================================         
    if (isset($_POST['supprimer1'])) 
       {
                $sql = "DELETE FROM client WHERE ID=$ID";
                mysqli_query ($lien,$sql);
                echo '<p align="center">un client avec l\'ID <u>'. $ID.'</u> est bien supprimer du table client.</p>';
        }
?>