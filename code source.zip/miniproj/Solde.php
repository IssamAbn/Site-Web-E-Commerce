<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="Accueil1.css">
  <script src="https://kit.fontawesome.com/17a6e4a4fc.js" crossorigin="anonymous"></script>
</head>
<body>
<<div id="banner1">
          <p> planete des jeux video PS4 </p>
        </div><br><br><br>
        <div id="menu">
           <ul>
           <li class="Acceuil"><a href="projet.php"><i class="fas fa-home"></i>     Acceuil</a></li>
              <li class="pn"><a href="panier.php"><i class="fas fa-shopping-cart"></i>  Panier</a></li>
              


    <li class="cnx"><a href="seconnecter.php">Connexion</a>
     <ul> 
      <?php if(!isset($_SESSION['ID'])){ ?>         
        <li class="secn"><a href="seconnecter.php"><i class="fas fa-sign-in-alt"></i> Se connecter</a></li>
        <li class="ins"><a href="inscription.php"><i class="far fa-edit"></i>S'inscrir
        </li> 
        <?php } else {?> 
        <li class="ins"><a href="sedecn.php"><i class="far fa-edit"></i>se deconnecter
        </li>
        <?php }?>
      </ul> 
    </li>



              <li class="jeux"><a href="jeux.php"><i class="fas fa-gamepad"></i>
    Les Jeux</a>
                  <ul>
                   <li class="avn"><a href="avanture.php"> <b>Avanture</b></a></li>
                   <li class="crs"><a href="course.php"> <b>course</b></a></li>
                   <li class="spr"><a href="sport.php"> <b>Sport</b></a></li>
                   <li class="br"><a href="br.php"> <b>Battle Royale</b></a></li>
                </ul>
              </li>
              <li class="sc"><a href="Contact.php"><i class="fas fa-info-circle"></i>       Service client</a>
                <ul>
                   <li class="cnt"><a href="Contacter.php"> <b><i class="fas fa-phone-square"></i>
                    Contactez-nous</b></a></li>
                   <li class="sld"><a href="Solde.php"> <b>Solde</b></a></li>
                </ul>
              </li>
              
           </ul>
        </div>
        <br><br><br><br>
</body>
</html>