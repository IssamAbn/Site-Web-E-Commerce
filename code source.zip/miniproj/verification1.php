<?php
     session_start();
     require("CnxBd.php");
     $lien=connectMaBasi();
     $ID=$_POST['ID'];
     $Mdp=$_POST['mdp'];
       if (isset($_POST['LOGIN'])) {
	     $query=" SELECT * FROM client WHERE ID=$ID ";
         $reslt=mysqli_query($lien,$query);
         $tab=mysqli_fetch_array($reslt);
         if ($Mdp==$tab[5]) 
         {
         	$_SESSION['ID'] = $tab[0] ;
            $_SESSION['pwd'] = $tab[5];
            if ($ID==1) {header('location:admin.php');}
            else{header('location:panier.php');}     
            
              
         }
        else 
        {
            header('location:seconnecter.php'); 
        }
        }
        
?>