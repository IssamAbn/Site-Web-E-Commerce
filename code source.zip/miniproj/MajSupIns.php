<?php  
    require("CnxBd.php");
    $lien=connectMaBasi();
    $ref    =$_POST['ref'];
    $prix   =$_POST['prix'];
    $Desi   =$_POST['Desi'];
    $cat    =$_POST['cat'];
    $prixacq=$_POST['prixacq'];
 
     if (isset($_POST['insérer']))
       {
                $sql = "INSERT INTO produit (Reference,Prix,Designation,Categorie,Prixacquisition) VALUES ('$ref','$prix','$Desi','$cat','$prixacq')";
                mysqli_query ($lien,$sql);
                echo '<p align="center">le produit avec reference <u>'.$ref.'</u> est bien inserer dans la table produit</p>';
        }
 //====================================================================================================    
    if (isset($_POST['Maj']))
       {     
                $sql = "UPDATE produit SET Prix='$prix' , Designation='$Desi' , Categorie='$cat' , Prixacquisition='$prixacq' WHERE Reference=$ref";
                mysqli_query ($lien,$sql);
                echo '<p align="center">le produit avec reference <u> '.$ref.'</u> est mise a jour dans la table produit.</p>';
        }
 //====================================================================================================     
    if (isset($_POST['supprimer'])) {
                $sql = "DELETE FROM produit WHERE Reference='$ref'";
                mysqli_query ($lien,$sql);
                echo '<p align="center">le produit avec la raference <u> '. $ref.'</u> est bien supprimer du table produit.</p>';
        }
?>