<?php 
session_start();
if (isset($_POST['ajt'])) {
  header('location:jeux.php');
}

if (isset($_POST['Valider'] )) {
  if($_SESSION['ID']){
    header('location:fincmd.php'); 
  }
  else{ echo "abn"; header('location:seconnecter.php'); }

}
 ?>