<?php  
    require("CnxBd.php");
    $lien=connectMaBasi();
   	$ID    =$_POST['ID'];
   	$Nom   =$_POST['Nom'];
   	$Tel   =$_POST['Tel'];
   	$Ville =$_POST['Ville'];
   	$Adress=$_POST['Adress'];
    $password=$_POST['password'];
    

    if (isset($_POST["S'INSCRIR"]))
       {
                $sql = "INSERT INTO client (ID,Nom,Tel,Ville,adresse,Motdepasse) VALUES ('$ID','$Nom','$Tel','$Ville','$Adress','$password')";
                mysqli_query ($lien,$sql);
                header('location:seconnecter.php');
        }