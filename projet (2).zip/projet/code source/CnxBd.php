<?php 
    function connectMaBasi()
    { 
       $basi = mysqli_connect ('localhost','root','','gestionclient');
       return $basi;
   }

?>